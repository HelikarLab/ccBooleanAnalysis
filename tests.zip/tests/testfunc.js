var ccbooleananalysis = require("../build/ccBooleanAnalysis.js");


// console.log(ccbooleananalysis.getParseTree("ROR AND AB"));
// console.log(ccbooleananalysis.getParseTree("AND"));
// console.log(ccbooleananalysis.getParseTree("NOT"));
// console.log(ccbooleananalysis.getParseTree("RAND OR NAND or LCKP1"));
// console.log(ccbooleananalysis.getParseTree("OR"));
// console.log(ccbooleananalysis.getParseTree("NOT AB"));
// console.log(ccbooleananalysis.getParseTree("NO OR ROR"));



// console.log('ROR + Y');
// console.log(ccbooleananalysis.getBiologicalConstructs('ROR + Y'));
//
// console.log("\n");
//
// console.log('NOT');
// console.log(ccbooleananalysis.getBiologicalConstructs('NOT'));


console.log(ccbooleananalysis.stateTransitionGraph(['B=A','C = A + B', 'A=B' ]));



let lacOperon = ["lac_mRNA = lac_operon",
                  "lac_repressor = ~(allolactose)",
                  "lac_enzymes = lac_mRNA",
                  "CAP = cAMP",
                  "lactose_breakdown = lac_enzymes * ~(lacZ_mutation)",
                   "allolactose = enviro_lactose",
                    "cAMP = ~(enviro_glucose)",
                    "lac_operon = CAP * ~((CAP_mutation + lac_repressor))"];

let TCellReceptor = ["cd28 = cd28", "tcrlig = tcrlig", "bclxl = ~(bad)", "bad = ~(pkb)", "calcin = cam * ~((cabin1 + calpr1 + akap79))", "akap79 = unknown_input2",
                  "cabin1 = ~(camk4)", "calpr1 = unknown_input2", "cam = ca", "camk4 = cam", "ikkg = (card11a * pkcth)", "card11a = (malt1 * (bcl10 * card11))",
                  "pkcth = (dag * (vav1 * pdk1))", "tcrb = tcrlig * ~(ccblp1)", "ccblp1 = (ccblr * fyn)", "zap70 = (tcrp * abl) * ~(ccblp1)", "tcrp = (tcrb * (fyn + lckp1))",
                  "abl = (fyn + lckp1)", "cblb = ~(cd28)", "dag = plcga * ~(dgk)", "dgk = tcrb", "plcga = ((plcgb * (vav1 * rlk * zap70 * slp76)) * …tk * (vav1 * plcgb * zap70 * slp76)) * ~(ccblp2))",
                  "shp1 = lckp1 * ~(erk)", "erk = mek", "lckp1 = (cd45 * lckr) * ~((shp1 * csk))", "slp76 = (zap70 * gads) * ~(gab2)", "gab2 = ((gads * (zap70 * lat)) + (grb2 * (zap70 * lat)))",
                  "gads = lat", "bcat = ~(gsk3)", "gsk3 = ~(pkb)", "cyc1 = ~(gsk3)", "nfkb = ~(ikb)", "ikb = ~(ikkab)", "ikkab = (ikkg * camk2)", "camk2 = cam", "pkb = pdk1", "fkhr = ~(pkb)", "p21c = ~(pkb)",
                  "p27k = ~(pkb)", "p38 = (zap70 + mekk1)", "gadd45 = unknown_input", "csk = pag", "cd45 = unknown_input", "lckr = lckr_input", "pag = fyn * ~(tcrb)", "ca = ip3", "nfat = calcin",
                  "ccblr = unknown_input", "fyn = ((lckp1 * cd45) + (tcrb * lckr))", "vav1 = ((zap70 * sh3bp2) + xx)", "xx = cd28", "mekk1 = (cdc42 + hpk1 + rac1p2)", "cdc42 = unknown_input2", "cre = creb",
                  "creb = rsk", "rasgrp = dag", "pdk1 = pip3", "fos = erk", "rsk = erk", "ap1 = (fos * jun)", "jun = jnk", "shp2 = gab2", "lat = zap70", "grb2 = lat", "hpk1 = lat", "mlk3 = (hpk1 + rac1p1)",
                  "ip3 = plcga", "jnk = (mekk1 + mkk4)", "plcgb = lat", "rlk = lckp1", "pi3k = (lckp2 * ~(cblb) + xx * ~(cblb))", "lckp2 = (lckr * tcrb)", "malt1 = unknown_input", "bcl10 = unknown_input2",
                  "card11 = unknown_input", "mek = raf", "mkk4 = (mekk1 + mlk3)", "p70s = pdk1", "pip3 = pi3k * ~((ship1 * pten))", "ship1 = unknown_input2", "pten = unknown_input2",
                  "itk = (pip3 * (zap70 * slp76))", "ccblp2 = (ccblr * fyn)", "rac1p1 = (rac1r * vav1)", "rac1p2 = (rac1r * vav3)", "sre = (rac1p2 + cdc42)", "rac1r = unknown_input", "vav3 = sh3bp2",
                  "raf = ras", "ras = (sos * rasgrp) * ~(gap)", "sh3bp2 = (zap70 * lat)", "gap = unknown_input3", "sos = grb2"];


let MammalianCell = ["UbcH10 = (Cdc20 * ~(Cdh1) + CycA * ~(Cdh1) + CycB …ycB))))) + ~(Cdh1 + Cdc20 + CycA + CycB + UbcH10)",
                  "p27 = p27 * ~((CycD + (CycA * CycE) + CycB)) + ~(CycE + CycA + CycB + CycD + p27)", "CycE = E2F * ~(Rb)",
                  "Rb = p27 * ~((CycD + CycB)) + ~(CycA + CycB + CycD + CycE + p27)", "Cdh1 = (Cdc20 + p27 * ~(CycB)) + ~(CycA + CycB + Cdc20 + p27)",
                  "Cdc20 = CycB", "CycB = ~((Cdc20 + Cdh1))", "CycA = (CycA * ~((Cdc20 + (Cdh1 * UbcH10) + Rb)) + E2F * ~((Cdc20 + (Cdh1 * UbcH10) + Rb)))",
                "CycD = CycD + ~(CycD)", "E2F = p27 * ~((CycB + Rb)) + ~(CycB + Rb + CycA + p27)"];

let guardCell = ["NO = (NOS * NIA12)", "NOS = Ca2_c", "NIA12 = RCN1", "PLC = (ABA * Ca2_c)", "Ca2_c = (CIS * ~(Ca2_ATPase) + CaIM * ~(Ca2_ATPase))", "CaIM = ((ABH1 * ~ERA1) * ~(Depolar) + (ERA1 * ~ABH…OS * ~(Depolar)) + ~(Depolar + ERA1 + ABH1 + ROS)", "Depolar = (AnionEM + (Ca2_c * (~KOUT + ~HTPase)) +…ase))) + ~(AnionEM + KOUT + HTPase + Ca2_c + KEV)", "ROS = Atrboh", "GPA1 = (AGB1 * ~(GCR1) + (S1P * AGB1))", "AGB1 = GPA1", "S1P = SphK", "Atrboh = (OST1 * (ROP2 * pH)) * ~(ABI1)", "ABI1 = pH * ~((PA + ROS))", "OST1 = ABA", "ROP2 = PA", "pH = ABA * ~(pH)", "HTPase = ~((Ca2_c + ROS + pH))", "Malate = PEPC * ~((ABA + AnionEM))", "AnionEM = ((Ca2_c * (~ABI1 + pH)) + (pH * (~ABI1 + Ca2_c)))", "PEPC = ~(ABA)", "RAC1 = ~((ABA + ABI1))", "Actin = Ca2_c * ~(RAC1)", "PA = PLD", "KAP = Depolar * ~((Ca2_c * pH))", "Ca2_ATPase = Ca2_c", "CIS = ((InsP3 * InsP6) + (cGMP * cADPR))", "InsP3 = PLC", "InsP6 = InsPK", "cGMP = GC", "cADPR = ADPRc", "KOUT = (Depolar * ~((ROS * NO)) + (pH * Depolar))", "KEV = Ca2_c", "Closure = ((KAP * (Actin * AnionEM)) * ~(Malate) + (KOUT * (Actin * AnionEM)) * ~(Malate))", "ADPRc = NO", "GC = NO", "InsPK = ABA",
"RCN1 = ABA", "PLD = GPA1", "SphK = ABA", "ROP10 = ERA1"];

// console.log(ccbooleananalysis.stateTransitionGraph(lacOperon));
// console.log(ccbooleananalysis.stateTransitionGraph(TCellReceptor));
// console.log(ccbooleananalysis.stateTransitionGraph(MammalianCell));
console.log(ccbooleananalysis.stateTransitionGraph(guardCell));
